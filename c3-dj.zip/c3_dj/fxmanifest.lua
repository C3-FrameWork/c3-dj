fx_version 'cerulean'
games { 'gta5' }
lua54 'yes'

author 'iTzZzCeh - C3'
description 'DJ PULT'
version '1.0.0'

server_scripts {
    'server.lua',
    'config.lua'
}

client_scripts {
    'client.lua',
    'config.lua'
}

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'config.lua'
}

dependencies {
    'es_extended',
    'ox_lib',
    'xsound'
}

escrow_ignore {
    'client.lua',
    'config.lua',
    'server.lua' -- ime fila kerga bo ignorala..
}

dependency '/assetpacks'