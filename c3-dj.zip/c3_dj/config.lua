Config = {}

--- Common settings ---
Config.Debug = false -- If you want debug in console
Config.DefaultVolume = 0.1 -- Accepted values are 0.01 - 1
Config.Distance = 5.0 -- Dont touch this

--- Target system ---
Config.ox_target = true -- If you want to use qtarget you need alzo polyzone script

--- Locations ---
Config.Locations = {
    {
        onlyJob = true, -- If false then everyone can access the location
        job = 'vanilla', -- if onJob true, you have to write the name of that job here like 'vanilla'
        name = 'Vanilla', -- Name of zone
        coords = vec3(120.5638, -1280.9021, 29.4805), -- Coordinates where menu will appear if you are nearby
        radius = 30, -- Playing music distance (radius)
        distance = 2.5, -- Menu appear distance
        isPlaying = false -- Dont touch this!!!!
    },
    {
        onlyJob = true,
        job = 'nil',
        name = 'Bahama',
        coords = vec3(-1382.05, -614.72, 31.5),
        radius = 30,
        distance = 2.5,
        isPlaying = false
    },
    {
        onlyJob = true,
        job = 'nil',
        name = 'Galaxy',
        coords = vec3(376.19, 275.45, 92.39),
        radius = 30,
        distance = 2.5,
        isPlaying = false
    },
    {
        onlyJob = false,
        job = 'nil',
        name = 'Tequila',
        coords = vec3(-562.11, 281.66, 85.6764),
        radius = 30,
        distance = 2.5,
        isPlaying = false
    },
    {
        onlyJob = false,
        job = 'nil',
        name = 'mansion pipenija silj',
        coords = vec3(3472.954, 4951.250, 35.235),
        radius = 30,
        distance = 3.5,
        isPlaying = false
    }
}

Config.Language = {
    ['openMenu'] = '[E] - Otvori DJ Izbornik',
    ['titleMenu'] = '💿 | DJ Pult',
    ['playSong'] = '🎶 | Reproducir pjesmu',
    ['playSongDesc'] = 'Unesite YouTube URL',
    ['pauseMusic'] = '⏸️ | Pauziraj glazbu',
    ['pauseMusicDesc'] = 'Pauziraj trenutno reproduciranu glazbu',
    ['resumeMusic'] = '▶️ | Nastavi glazbu',
    ['resumeMusicDesc'] = 'Nastavi s reprodukcijom pauzirane glazbe',
    ['changeVolume'] = '🔈 | Promijeni glasnocu',
    ['changeVolumeDesc'] = 'Promijeni glasnocu pjesme',
    ['stopMusic'] = '❌ | Iskljuci glazbu',
    ['stopMusicDesc'] = 'Iskljuci glazbu i odaberi novu pjesmu',
    ['songSel'] = 'Odabir pjesme',
    ['url'] = 'YouTube URL',
    ['musicVolume'] = 'Glasnoca glazbe',
    ['musicVolumeNm'] = 'Min: 0.01 - Max: 1', -- Molimo vas da ne mijenjate brojeve (0.01 - 1)

    --- Popis pjesama ---
    ['playlistMenu'] = '🎶 | DJ Pult Popis pjesama',
    ['playlistDesc'] = 'Reproduciraj pjesmu s popisa pjesama',
    ['playlistMenuTitle'] = '🎶 | Reproducir pjesmu'
}


Config.Playlist = {
    --- example ---
    ['first'] = '💿 | Mess', -- Name of first song
    ['desc_first'] = 'Description of the song', -- Description of the song
    ['music_first_id'] = 'https://www.youtube.com/watch?v=-Kjrf-pxQc4', -- Url from YT

    --- example ---
    ['second'] = '💿 | Shiver', -- Name of second song
    ['desc_second'] = 'Description of the song',
    ['music_second_id'] = 'https://www.youtube.com/watch?v=NdUNtHqY5r8',

    --- example ---
    ['third'] = '💿 | Good With It', -- Name of third song
    ['desc_third'] = 'Description of the song',
    ['music_third_id'] = 'https://www.youtube.com/watch?v=RInypZYiiDM',

    --- example ---
    ['fourth'] = '💿 | Back To You',
    ['desc_fourth'] = 'Description of the song',
    ['music_fourth_id'] = 'https://www.youtube.com/watch?v=rrzHAoA-oRI',

    --- example ---
    ['fifth'] = '💿 | Curse',
    ['desc_fifth'] = 'Description of the song',
    ['music_fifth_id'] = 'https://www.youtube.com/watch?v=XsmuiDRKbDk'
}
