local xSound = exports.xsound

RegisterNetEvent('c3_dj:playMusic', function (YoutubeURL)
    for k, v in pairs(Config.Locations) do
        local defaultVolume = Config.DefaultVolume
        local src = source
        local ped = GetPlayerPed(src)
        local coords = GetEntityCoords(ped)
        local dist = #(coords - v.coords)
        if dist < 3 then
            xSound:PlayUrlPos(-1, v.name, YoutubeURL, defaultVolume, coords)
            xSound:Distance(-1, v.name, v.radius)
            v.isPlaying = true
            if Config.Debug then
                print('DEBUG c3_dj | Glazba je počela svirati na koordinatama: '..coords..' in radius: '..v.radius)
            end
        end
    end
end)

RegisterNetEvent('c3_dj:stopMusic', function()
    for k, v in pairs(Config.Locations) do
        local src = source
        local ped = GetPlayerPed(src)
        local coords = GetEntityCoords(ped)
        local dist = #(coords - v.coords)
        if dist < 3 then
            if v.isPlaying then
                v.isPlaying = false
                xSound:Destroy(-1, v.name)
                if Config.Debug then
                    print('DEBUG c3_dj | Glazba isključena na koordinatama: '..coords)
                end
            end
        end
    end
end)

RegisterNetEvent('c3_dj:pauseMusic', function()
    for k, v in pairs(Config.Locations) do
        local src = source
        local ped = GetPlayerPed(src)
        local coords = GetEntityCoords(ped)
        local dist = #(coords - v.coords)
        if dist < 3 then
            if v.isPlaying then
                v.isPlaying = false
                xSound:Pause(-1, v.name)
                if Config.Debug then
                    print('DEBUG c3_dj | Glazba je pauzirana na koordinatama:'..coords)
                end
            end
        end
    end
end)

RegisterNetEvent('c3_dj:resumeMusic', function()
    for k, v in pairs(Config.Locations) do
        local src = source
        local ped = GetPlayerPed(src)
        local coords = GetEntityCoords(ped)
        local dist = #(coords - v.coords)
        if dist < 3 then
            if not v.isPlaying then
                v.isPlaying = true
                xSound:Resume(-1, v.name)
                if Config.Debug then
                    print('DEBUG c3_dj | Glazba nastavljena na koordinatama: '..coords)
                end
            end
        end
    end
end)

RegisterNetEvent('c3_dj:changeVolume', function(volume)
    for k, v in pairs(Config.Locations) do
        local src = source
        local ped = GetPlayerPed(src)
        local coords = GetEntityCoords(ped)
        local dist = #(coords - v.coords)
        if dist < 3 then
            if not tonumber(volume) then return end
            if v.isPlaying then 
                xSound:setVolume(-1, v.name, volume)
                if Config.Debug then
                    print('DEBUG c3_dj | Glasnoca Glasbe: '..volume)
                end
            end
        end
    end
end)
